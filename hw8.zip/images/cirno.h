#ifndef CIRNO_BITMAP_H
#define CIRNO_BITMAP_H
extern const unsigned short cirno[256];
#define CIRNO_WIDTH 16
#define CIRNO_HEIGHT 16
#endif