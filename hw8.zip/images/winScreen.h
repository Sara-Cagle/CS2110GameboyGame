#ifndef WINSCREEN_BITMAP_H
#define WINSCREEN_BITMAP_H
extern const unsigned short winScreen[38400];
#define WINSCREEN_WIDTH 240
#define WINSCREEN_HEIGHT 160
#endif