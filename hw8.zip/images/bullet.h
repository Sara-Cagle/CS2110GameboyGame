#ifndef BULLET_BITMAP_H
#define BULLET_BITMAP_H
extern const unsigned short bullet[256];
#define BULLET_WIDTH 16
#define BULLET_HEIGHT 16
#endif