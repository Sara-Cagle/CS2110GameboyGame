#ifndef CREDITSCREEN_BITMAP_H
#define CREDITSCREEN_BITMAP_H
extern const unsigned short creditScreen[38400];
#define CREDITSCREEN_WIDTH 240
#define CREDITSCREEN_HEIGHT 160
#endif