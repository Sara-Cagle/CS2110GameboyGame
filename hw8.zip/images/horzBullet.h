#ifndef HORZBULLET_BITMAP_H
#define HORZBULLET_BITMAP_H
extern const unsigned short horzBullet[256];
#define HORZBULLET_WIDTH 16
#define HORZBULLET_HEIGHT 16
#endif