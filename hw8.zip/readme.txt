Cirno Ice Fall
by Sara Cagle
CS 2110

Loosely based on the bullet hell game, Touhou Project.

Avoid the ice bullets by moving around and gain points by staying alive.
Being hit by an ice bullet will end the game. You only have one life.
A specified amount of bullets will cross the screen from random locations and at random speeds.
Bullets are "recycled" and relocated after they fly off the screen.
Your score is located on the bottom, and increments whenever a FALLING ice bullet passes you.
Horizontal bullets do not give you points, but are another obstacle you must avoid.

Directions are explained in-game.

The number of points required to win can be changed at the top of the main file.
	They're defaulted at 20 in WINNINGSCORE.
The number of bullets can be changed at the top of the main file.
The same number of bullets will be created for both types of bullets.
	For example, it's defaulted at 2, so 2 bullets of each type, 4 bullets total, will be created.
	This can be changed by changing NUMBULLET.
